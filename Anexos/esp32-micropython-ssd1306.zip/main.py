from machine import Pin, I2C
import dht
import time
from ssd1306 import SSD1306_I2C
# Wokwi Library List
# See https://docs.wokwi.com/guides/libraries

ssd1306
# =====================================================
# OLED
# =====================================================

i2c = I2C(
    0,
    scl=Pin(22),
    sda=Pin(21)
)

oled = SSD1306_I2C(128, 64, i2c)

# =====================================================
# DHT22
# =====================================================

sensor = dht.DHT22(Pin(16))

# =====================================================
# SALIDAS
# =====================================================

relay_temp = Pin(5, Pin.OUT)

led_rojo = Pin(12, Pin.OUT)

led_azul = Pin(14, Pin.OUT)

buzzer = Pin(15, Pin.OUT)

humidificador = Pin(4, Pin.OUT)

# =====================================================
# SENSOR PUERTA
# =====================================================

sensor_puerta = Pin(
    33,
    Pin.IN,
    Pin.PULL_UP
)

# =====================================================
# ESTADOS INICIALES
# =====================================================

relay_temp.value(0)

led_rojo.value(0)

led_azul.value(0)

buzzer.value(0)

humidificador.value(0)

# =====================================================
# PARAMETROS
# =====================================================

TEMP_MIN = 35.5
TEMP_MAX = 36.5

HUM_MIN = 40
HUM_MAX = 60

# =====================================================
# VARIABLES
# =====================================================

calefactor_on = False
humificador_on = False

tiempo_puerta = 0

# =====================================================
# LOOP
# =====================================================

while True:

    try:

        sensor.measure()

        temp = sensor.temperature()

        hum = sensor.humidity()

    except:

        oled.fill(0)

        oled.text("ERROR DHT22", 0, 20)

        oled.show()

        buzzer.value(1)

        time.sleep(1)

        continue

    # =================================================
    # CONTROL TEMPERATURA
    # =================================================

    if temp < TEMP_MIN:

        relay_temp.value(1)

        calefactor_on = True

    elif temp > TEMP_MAX:

        relay_temp.value(0)

        calefactor_on = False

    # =================================================
    # LEDS
    # =================================================

    led_azul.value(1 if temp < TEMP_MIN else 0)

    led_rojo.value(1 if temp > TEMP_MAX else 0)

    # =================================================
    # CONTROL HUMEDAD
    # =================================================

    if hum < HUM_MIN and not humificador_on:

        humidificador.value(1)

        time.sleep_ms(500)

        humidificador.value(0)

        humificador_on = True

    elif hum > HUM_MAX and humificador_on:

        humidificador.value(1)

        time.sleep_ms(500)

        humidificador.value(0)

        humificador_on = False

    # =================================================
    # SENSOR PUERTA
    # =================================================

    puerta_abierta = (
        sensor_puerta.value() == 1
    )

    if puerta_abierta:

        if tiempo_puerta == 0:

            tiempo_puerta = time.ticks_ms()

        else:

            delta = time.ticks_diff(
                time.ticks_ms(),
                tiempo_puerta
            )

            if delta > 5000:

                buzzer.value(1)

    else:

        tiempo_puerta = 0

        buzzer.value(0)

    # =================================================
    # OLED
    # =================================================

    oled.fill(0)

    oled.text("INCUBADORA", 0, 0)

    oled.text(
        "Temp: {:.1f}C".format(temp),
        0,
        16
    )

    oled.text(
        "Hum : {:.1f}%".format(hum),
        0,
        30
    )

    oled.text(
        "CAL: {}".format(
            "ON" if calefactor_on else "OFF"
        ),
        0,
        46
    )

    oled.text(
        "HUM: {}".format(
            "ON" if humificador_on else "OFF"
        ),
        64,
        46
    )

    if puerta_abierta:

        oled.text(
            "PUERTA ABIERTA",
            0,
            56
        )

    oled.show()

    time.sleep(1)